---
title: "Layout: Excerpt (Defined)"
excerpt: "This is a user-defined post excerpt. It should be displayed in place of the post content in archive-index pages."
categories:
  - Layout
  - Uncategorized
tags:
  - content
  - excerpt
  - layout
---

This is the post content. It should be displayed in place of the user-defined excerpt in archive-index pages.

This paragraph should be absent from an archive-index page where `post.excerpt` is shown.