---
title: "Layout: Excerpt (Generated)"
excerpt_separator: "<!--more-->"
categories:
  - Layout
  - Uncategorized
tags:
  - content
  - excerpt
  - layout
---

This is the post content. Archive-index pages should display an auto-generated excerpt of this content.

<!--more-->

Be sure to test the formatting of the auto-generated excerpt, to ensure that it doesn't create any layout problems.